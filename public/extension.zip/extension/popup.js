document.getElementById('scrapeBtn').addEventListener('click', async () => {
    const statusDiv = document.getElementById('status');
    statusDiv.innerHTML = "⏳ กำลังดึงข้อมูล...";

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (tab?.id) {
        chrome.tabs.sendMessage(tab.id, { action: "SCRAPE" }, (response) => {
            if (chrome.runtime.lastError) {
                statusDiv.innerHTML = `<span style="color: #ef4444;">❌ Error: กรุณา Refresh หน้าสินค้าแล้วลองใหม่</span>`;
            } else if (response && response.data) {
                const { title, image, price } = response.data;
                statusDiv.innerHTML = `
                    <div style="margin-top: 15px; background: #1e293b; padding: 10px; border-radius: 8px;">
                        <img src="${image}" style="width: 100%; border-radius: 6px; margin-bottom: 8px;">
                        <div style="font-size: 13px; margin-bottom: 4px;">${title}</div>
                        <div style="color: #34d399; font-weight: bold;">${price}</div>
                    </div>
                `;
            } else {
                statusDiv.innerHTML = "⚠️ ไม่พบข้อมูลสินค้าในหน้านี้";
            }
        });
    }
});