console.log("AI Affiliate Extension Loaded");

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "SCRAPE") {
        console.log("Dumping product info...");
        const product = scrapeProductData();

        if (product) {
            sendResponse({ message: "ดึงข้อมูลสำเร็จ!", data: product });
        } else {
            sendResponse({ message: "ไม่พบข้อมูลสินค้า" });
        }
    }
    return true; // Keep channel open for async response
});

function scrapeProductData() {
    // 1. Try Open Graph Metadata (Standard)
    let title = document.querySelector('meta[property="og:title"]')?.content || document.title;
    let image = document.querySelector('meta[property="og:image"]')?.content;
    let price = document.querySelector('meta[property="product:price:amount"]')?.content;

    // 2. Platform Specific Fallbacks

    // TikTok Shop
    if (window.location.hostname.includes("tiktok.com")) {
        if (!title) title = document.querySelector('h1')?.innerText;
        if (!price) price = document.querySelector('.price, [data-test-id="product-price"]')?.innerText;
        // Image usually covered by OG tags
    }

    // Shopee
    if (window.location.hostname.includes("shopee")) {
        if (!title) title = document.querySelector('.attM6y span, .qaNIZv span')?.innerText; // Common obfuscated classes
        if (!price) price = document.querySelector('.pqTWkA')?.innerText;
    }

    // Generic Fallback
    if (!image) {
        const firstImg = document.querySelector('img[width="500"], .product-image img, main img');
        if (firstImg) image = firstImg.src;
    }

    return {
        title: title?.trim().substring(0, 100) + "...",
        image: image,
        price: price || "N/A",
        url: window.location.href
    };
}
